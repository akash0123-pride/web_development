# background-generator
basic html ,css and javascript to create background generator.
issues- write javascript for this.
requirements- background default  color should be blue-black.

